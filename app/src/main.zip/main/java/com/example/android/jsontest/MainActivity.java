package com.example.android.jsontest;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.ArrayAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList feedList;
    MyListAdapter mLA;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Before attempting to fetch the URL, makes sure that there is a network connection.
        String stringUrl = "http://jsonplaceholder.typicode.com/posts/1/comments";
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            new MyAsynkTask().execute(stringUrl);
            Log.v("yay", "Connected");
        } else {
            Log.v("No network", "Connection");
        }
        mLA = new MyListAdapter(this);
        ListView mList = (ListView) findViewById(R.id.custom_list);
        mList.setAdapter(mLA);
    }


    public class MyAsynkTask extends AsyncTask<String, Void, Integer> {

        @Override
        protected Integer doInBackground(String... params) {
            InputStream inputStream = null;
            HttpURLConnection urlConnection;
            JSONArray jObj = null;
            String json = null;
            feedList = new ArrayList();

            try {
                URL url = new URL(params[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setReadTimeout(10000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoInput(true); //???
                urlConnection.connect();
                int statusCode = urlConnection.getResponseCode();

                //once the resonse is there: 3 options
                //a) stream parsing (not building a buffer) - looking for json markers - old and painful
                //b) string parsing (make a buffer, convert into a long string, use json library to create array)
                //c) GSON library. uses class reflection to build json array.

                /* 200 represents HTTP OK */
                if (statusCode == 200) {
                    //inputStream = new BufferedInputStream(urlConnection.getInputStream());
                    try {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"), 8);
                        StringBuilder sb = new StringBuilder();
                        String line = null;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line + "\n");
                        }
                        json = sb.toString();

                        jObj = new JSONArray(json);
                    } catch (JSONException e) {

                    }

                    //parsing json data
                    for (int i = 0; i < jObj.length(); i++) {
                        try {
                            JSONObject jsonElement = jObj.getJSONObject(i);
                            String name = jsonElement.getString("name");
                            String email = jsonElement.getString("email");
                            String body = jsonElement.getString("body");
                            FeedItem item = new FeedItem();
                            item.setName(name);
                            item.setEmail(email);
                            item.setBody(body);
                            feedList.add(item);

                        } catch (JSONException e) {
                        }
                    }
                }
            } catch (Exception e) {
            }
            // Makes sure that the InputStream is closed after the app is
            // finished using it.
            finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (Exception e) {

                    }
                }
            }
            return 0;
        }


        @Override
        protected void onPostExecute (Integer i) {
            mLA.setData(feedList);
            mLA.notifyDataSetChanged();
        }




    }
}