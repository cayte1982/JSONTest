package com.example.android.jsontest;

import java.io.Serializable;

/**
 * Created by cayte on 11/19/15.
 */
public class FeedItem implements Serializable {
    private String name;
    private String email;
    private String body;

    public String getName(){
        return name;
    }
    public String getEmail(){
        return email;
    }
    public String getBody(){
        return body;
    }
    public void setName(String n){
        this.name = n;
    }
    public void setEmail(String e){
        this.email = e;
    }
    public void setBody(String b){
        this.body = b;
    }

}
