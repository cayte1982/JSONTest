package com.example.android.jsontest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by cayte on 11/19/15.
 */
public class MyListAdapter extends BaseAdapter {
    private ArrayList<FeedItem> listData;
    private LayoutInflater layoutInflater;
    private Context mContext;

    public MyListAdapter(Context context) {
        layoutInflater = LayoutInflater.from(context);
        listData = new ArrayList<FeedItem>();
        mContext = context;
    }

    public void setData(ArrayList<FeedItem> items) {
        listData.addAll(items);
    }

    @Override
    public int getCount() {
        return listData.size();
    }

    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        convertView = layoutInflater.inflate(R.layout.list_row_layout, null);
        holder = new ViewHolder();
        holder.nameView = (TextView) convertView.findViewById(R.id.name);
        holder.emailView = (TextView) convertView.findViewById(R.id.email);
        holder.bodyView = (TextView) convertView.findViewById(R.id.body);

        FeedItem myItem = (FeedItem) listData.get(position);
        holder.nameView.setText(myItem.getName());
        holder.emailView.setText(myItem.getEmail());
        holder.bodyView.setText(myItem.getBody());

        return convertView;
    }

    static class ViewHolder {
        TextView nameView;
        TextView emailView;
        TextView bodyView;
    }
}
